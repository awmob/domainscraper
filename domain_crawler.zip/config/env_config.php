<?php

global $env_config;

$env_config = array(

  'app_name' => 'The Scraper'

);
